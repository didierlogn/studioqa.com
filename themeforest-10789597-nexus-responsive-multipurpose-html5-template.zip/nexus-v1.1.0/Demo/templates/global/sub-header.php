<section class="hero sub-header">
    <div class="container inactive">
        <div class="sh-title-wrapper">
            <h1><?php echo $title; ?></h1>
            <p>Aenean lobortis ante nunc. Integer ac justo ex. Curabitur at enim ac nisi lacinia.</p>
            <a href="<?php echo $purchase; ?>" target="blank" class="button border round cta">Purchase Theme</a>
        </div>
    </div>
</section>