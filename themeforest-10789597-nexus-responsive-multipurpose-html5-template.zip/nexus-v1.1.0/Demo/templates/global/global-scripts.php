<!-- jQuery -->
<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>-->
<script src="<?php echo $ROOT; ?>assets/js/jquery.min.js"></script>

<!-- LivIcons -->
<script src="<?php echo $ROOT; ?>assets/js/raphael.min.js"></script>
<script src="<?php echo $ROOT; ?>assets/js/livicons-custom.min.js"></script>

<!--Plugins -->
<script src="<?php echo $ROOT; ?>assets/js/owl-carousel.min.js"></script>
<script src="<?php echo $ROOT; ?>assets/js/magnific-popup.min.js"></script>