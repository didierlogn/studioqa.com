<?php if ($demo == true) { ?>
<!-- Theme Options -->
<!-- Cookie (for theme color-switcher) -->
<script src="<?php echo $ROOT; ?>assets/js/cookie.js"></script>
<!--[if IE 9]>     <script>$('.theme-options').hide();</script> <![endif]-->
<!--[if gt IE 9]>  <script src="<?php echo $ROOT; ?>assets/js/theme-options.js"></script> <![endif]-->
<!--[if !IE]><!--> <script src="<?php echo $ROOT; ?>assets/js/theme-options.js"></script> <!--<![endif]-->
<?php } ?>