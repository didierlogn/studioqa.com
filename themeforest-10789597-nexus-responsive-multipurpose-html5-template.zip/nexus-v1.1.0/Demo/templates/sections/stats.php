<section class="stats row block-columns">
    <div class="stat span-3">
        <i class="livicon" data-n="code" data-c="#ffffff" data-op="1" data-s="68" data-hc="false"></i>
        <h4><span id="stat-1" data-val="14266">0</span></h4>
        <p>Lines of code</p>
    </div>
    <div class="stat span-3">
        <i class="livicon" data-n="rocket" data-c="#ffffff" data-op="1" data-s="68" data-hc="false"></i>
        <h4><span id="stat-2" data-val="136">0</span></h4>
        <p>Completed projects
    </div>
    <div class="stat span-3">
        <i class="livicon" data-n="users" data-c="#ffffff" data-op="1" data-s="68" data-hc="false"></i>
        <h4><span id="stat-4" data-val="28">0</span></h4>
        <p>Happy clients</p>
    </div>
    <div class="stat span-3">
        <i class="livicon" data-n="barchart" data-c="#ffffff" data-op="1" data-s="68" data-hc="false"></i>
        <h4><span id="stat-3" data-val="3254">0</span></h4>
        <p>Sales
    </div>
</section>