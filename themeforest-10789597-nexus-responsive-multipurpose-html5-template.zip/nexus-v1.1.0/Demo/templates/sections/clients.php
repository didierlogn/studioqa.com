<section class="section secondary clients">
    <div class="container">
        <div class="row">
            <div class="span-4 title">
                <div class="section-title title-group">
                    <h2>Our Clients</h2>
                    <h5>Meet Our Happy Clients</h5>
                </div>
            </div>
            <div class="span-8 client-logos">  
                <div class="owl-carousel clients-slider"> 
                    <a href="#">                     
                        <img src="<?php echo $ROOT; ?>assets/images/envato/envato-1.png" alt="" />
                    </a> 
                    <a href="#">                     
                        <img src="<?php echo $ROOT; ?>assets/images/envato/envato-2.png" alt="" />
                    </a> 
                    <a href="#">                     
                        <img src="<?php echo $ROOT; ?>assets/images/envato/envato-3.png" alt="" />
                    </a> 
                    <a href="#">                     
                        <img src="<?php echo $ROOT; ?>assets/images/envato/envato-4.png" alt="" />
                    </a> 
                    <a href="#">                     
                        <img src="<?php echo $ROOT; ?>assets/images/envato/envato-5.png" alt="" />
                    </a> 
                    <a href="#">                     
                        <img src="<?php echo $ROOT; ?>assets/images/envato/envato-6.png" alt="" />
                    </a> 
                    <a href="#">                     
                        <img src="<?php echo $ROOT; ?>assets/images/envato/envato-7.png" alt="" />
                    </a> 
                    <a href="#">                     
                        <img src="<?php echo $ROOT; ?>assets/images/envato/envato-8.png" alt="" />
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>