<section class="section quote">
    <div class="container">
        <blockquote class="active">
            <h4>We can take your awesome ideas and turn them into an <b>exciting reality</b>...</h4>
        </blockquote>
    </div>
</section>